#coding:utf-8
from django.apps import AppConfig


class AssetmanageConfig(AppConfig):
    name = 'AssetManage'
    verbose_name =  '资产模块'
