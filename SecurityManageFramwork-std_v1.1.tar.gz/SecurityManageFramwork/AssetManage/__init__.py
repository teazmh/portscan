#coding:utf-8


default_app_config = 'AssetManage.apps.AssetmanageConfig'